import logo from './logo.svg';
import './components/virtualkitchen';
import './App.css';
import VirtualKitchen from './components/virtualkitchen';

function App() {
  return (

    <div className="App">
      <VirtualKitchen/>
    </div>
  );
}

export default App;
