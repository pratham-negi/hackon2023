frameppt = document.getElementById("pptframe");

document.getElementById("submitButton").addEventListener("click", function() {
    var inputText = document.getElementById("textInput").value;
    document.getElementById("outputText").innerText = inputText;
    const query = new URLSearchParams({ param: inputText  }); 


    
    console.log("getting");
    makeRequest(query);
    
  });
  
  document.querySelector(".close").addEventListener("click", closePopup);
  
  function openPopup(data) {
    var popup = document.getElementById("popup");
    popup.style.display = "block";
    link = document.getElementById('link');
    console.log(link);
    link.addEventListener('click',()=>{
      const response = fetch(`http://127.0.0.1:5000/download?param=${data.data}`).then(response => response.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
    
        const link = document.createElement('a');
        link.href = url;
        link.download = `${data.data}.pptx`;
        document.body.appendChild(link);
        link.click();
        URL.revokeObjectURL(url);
        link.remove();
      })
      .catch(error => {
        console.error('Error:', error);
      });
    ;
      console.log(response)
      
    })
    

    
    
    
  }
  
  function closePopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "none";
  }
  

  async function makeRequest(query) {
    try {
      console.log("first");
      const loadingAnimation = document.getElementById('loading-animation');
      loadingAnimation.style.display = 'block';
      console.log("second");
      const response = await fetch(`http://127.0.0.1:5000/generate_ppt?${query}`);
      const data = await response.json();
      console.log(data);
      loadingAnimation.style.display = 'none';
      openPopup(data);
      } catch (error) {
      console.log('Error:', error);
      }
  }
  
  