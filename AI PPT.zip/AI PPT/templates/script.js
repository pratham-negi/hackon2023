document.getElementById("submitButton").addEventListener("click", function() {
    var inputText = document.getElementById("textInput").value;
    document.getElementById("outputText").innerText = inputText;
    openPopup();
  });
  
  document.querySelector(".close").addEventListener("click", closePopup);
  
  function openPopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "block";
  }
  
  function closePopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "none";
  }
  