from flask import Flask, render_template, request,  send_file
from static.textppt import *

# import your_ppt_generation_module  # Import your module for generating the PPT

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/generate_ppt', methods = ['GET','POST'])
def generate_ppt():
    query = request.args.get('param')
    data =  ppt(query)
    return({"data": query})

@app.route('/download', methods = ['GET','POST'])
def download_file():
    query = request.args.get('param')
    file_path = query+'.pptx'

    return send_file(file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(host="localhost", port=8000, debug=True)
