const express = require('express');
const { MongoClient } = require('mongodb');
const bodyParser = require('body-parser');
const cors = require('cors');
const cookieParser = require("cookie-parser");
const session = require('express-session');

const oneDay = 1000 * 60 * 60 * 24;

var urlencodedParser = bodyParser.urlencoded({ extended: false });

const app = express();

app.use(cors({
  origin: '*'
}));

app.use(session({
  secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
  saveUninitialized: true,
  cookie: { maxAge: oneDay },
  resave: true,
  store: new session.MemoryStore() 
}));

app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

const port = 8000;

const uri = "mongodb+srv://prathamnegi1:KzbK2HrPVlkRrajF@vectors.v4evvu7.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);

app.get('/', (req, res) => {
  if (req.session.userid) {
    res.send(req.session.userid);
  } else {
    res.send({"k":3});
  }
});

app.post('/signup', urlencodedParser, async (req, res) => {
  try {
    await client.connect();
    const database = client.db('vectors');
    const collection = database.collection('user');
    const count = await collection.countDocuments();
    console.log(req.body);

    const document = {
      id: count + 1,
      user: req.body.user,
      email: req.body.email,
      password: req.body.password
    };

    session=req.session;
    session.userid=req.body.user;

    const result = await collection.insertOne(document);
    res.send('done');
  } catch(err) {
    console.log(err);
  } finally {
    await client.close();
  }
});

app.post('/', urlencodedParser, async (req, res) => {
  try {
    await client.connect();
    const database = client.db('vectors');
    const collection = database.collection('user');
    const user = await collection.find().toArray();
    flag = false;
    for(let i = 0; i < user.length;i++){
      if(user[i].email == req.body.email){
          user[i].password == req.body.password;
          flag = true;
          break;

      }
    }

    session=req.session;
    session.userid=req.body.email;
    console.log(req.body);
    console.log(user);
    res.send({"k":true});
  } catch(err) {
    console.log(err);
  } finally {
    client.close();
  }
});

app.post('/question', urlencodedParser, async (req, res) => {
  try {
    await client.connect();
    const database = client.db('vectors');
    const collection = database.collection('questions');
    const count = await collection.countDocuments();
    const currentDate = new Date();

    const document = {
      id: count + 1,
      header: req.body.question,
      question: req.body.your_question,
      category: req.body.category,
      tags: req.body.tags,
      date: currentDate
    };

    const result = await collection.insertOne(document);
    res.json("done");
  } catch (error) {
    console.log(error);
  } finally {
    await client.close();
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.get('/question', async (req, res) => {
  try {
    await client.connect();
    const database = client.db('vectors');
    const collection = database.collection('questions');
    const questions = await collection.find().toArray();
    res.status(200).json(questions);
  } catch (error) {
    console.error('Failed to fetch questions:', error);
    res.status(500).json({ error: 'Failed to fetch questions' });
  } finally {
    await client.close();
  }
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
