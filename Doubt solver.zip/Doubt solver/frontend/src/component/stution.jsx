import React, { useState, useEffect } from 'react';
import './style.css';
import AssignmentHelp from './assignmentHelp';

function Stution(props) {
    const [isDarkMode, setIsDarkMode] = useState(false);

    const toggleSidebar = () => {
      const sidebar = document.querySelector('.sidebar');
      sidebar.classList.toggle('close');
    };
  
    const openSidebar = () => {
      const sidebar = document.querySelector('.sidebar');
      sidebar.classList.toggle('close');
    };
  
    // useEffect(() => {
    //     fetch('http://localhost:8080/api/stution')
    //        .then(res => res.json())
    //        .then(data => {
    //             setStution(data);
    //             setLoading(false);
    //         })
    //        .catch(err => {
    //             setError(true);
    //             setMessage(err.message);
    //             setLoading(false);
    //         });
    // }, []);

    return (
        
        <div className="container2" style={{display:props.dis}}>
            <nav className="sidebar close">
        <header>
            <div className="image-text">
                <span className="image">
                    <img src="favicon1.jpg" alt=""/>
                </span>

                <div className="text logo-text">
                    <span className="name">&nbsp; &nbsp; Stution</span>
                    <span className="profession">&nbsp; &nbsp; One Stop Solution</span>
                </div>
            </div>

            <i className='bx bx-chevron-right toggle' onClick={openSidebar}></i>
        </header>

        <div className="menu-bar">
            <div className="menu">

                <ul className="menu-links">
                    <li className="nav-link">
                        <a href="#">
                            <i className='bx bx-home-alt icon' ></i>
                            <span className="text nav-text">Assignment Solver</span>
                        </a>
                    </li>

                    <li className="nav-link">
                        <a href="#">
                            <i className='bx bx-bar-chart-alt-2 icon' ></i>
                            <span className="text nav-text">Events Manager</span>
                        </a>
                    </li>

                    <li className="nav-link">
                        <a href="#">
                            <i className='bx bx-wallet icon'></i>
                            <span className="text nav-text">Info Centre</span>
                        </a>
                    </li>

                    <li className="nav-link">
                        <a href="#">
                            <i className='bx bx-pie-chart-alt icon' ></i>
                            <span className="text nav-text">Community Connector</span>
                        </a>
                    </li>

                    

                </ul>
            </div>

            <div className="bottom-content">
                <li className="">
                    <a href="#">
                        <i className='bx bx-user icon' ></i>
                        <span className="text nav-text">Profile</span>
                    </a>
                </li>

                <li className="">
                    <a href="http://localhost:3000"  onClick={()=>{
                        const res = fetch('http://localhost:8000/logout');
                    }}>
                        <i className='bx bx-log-out icon' ></i>
                        <span className="text nav-text">Logout</span>
                    </a>
                </li>

                
                
            </div>
        </div>

    </nav>

            <AssignmentHelp/>
        </div>
    );
}
export default Stution;
