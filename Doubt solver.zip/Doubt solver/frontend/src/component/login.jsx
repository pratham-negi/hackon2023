import React, { useState, useEffect } from 'react';
import './style.css';

function Login(){
    return(<div className="hero">
        <div className="form-box">
            <div className="button-box">
                <div id="btn" />
                <button className="toggle-btn" type="button" onclick="login()">
                    Login
                </button>
                <button className="toggle-btn" type="button" onclick="register()">
                    Register
                </button>
            </div>
            <div className="social-icons">
                <img src="/img/facebook.png" title="Facebook" />
                <img src="/img/google.png" title="Google" />
                <img src="/img/linkedin.png" title="Linkedin" />
            </div>
            <form action="" className="input-group" id="login">
                <input
                    type="text"
                    className="input-field"
                    placeholder="Username"
                    required=""
                />
                <input
                    type="text"
                    className="input-field"
                    placeholder="Password"
                    required=""
                />
                <input type="checkbox" className="check-box" />
                <span>Remember Password</span>
                <button className="submit-btn" type="submit">
                    Login
                </button>
            </form>
            <form action="" className="input-group" id="register">
                <input
                    type="text"
                    className="input-field"
                    placeholder="Username"
                    required=""
                />
                <input
                    type="email"
                    className="input-field"
                    placeholder="Email id"
                    required=""
                />
                <input
                    type="text"
                    className="input-field"
                    placeholder="Password"
                    required=""
                />
                <input type="checkbox" className="check-box" />
                <span>I agree to the terms &amp; conditions</span>
                <button className="submit-btn" type="submit">
                    Register
                </button>
            </form>
        </div>
    </div>)
}

export default Login;
