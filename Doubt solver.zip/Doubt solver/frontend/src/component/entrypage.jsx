import React, { useState } from 'react';
import './FormContainer.css';
import axios from 'axios';

const Entrypage = (props) => {
  const [panelActive, setPanelActive] = useState(false);

  const [email,setEmail ]= useState('');
  const [user,setUser] = useState('');
  const [password, setPassword] = useState('');

  const [logemail , setlogemail] = useState('');
  const [logpassword, setlogpassword] = useState('');

  const handleSignInClick = () => {
    setPanelActive(true);
  };

  const handleSignUpClick = () => {
    setPanelActive(false);
  };

  function handler(){
    props.setDis('none');
  }

  return (
    <div className='backoverflow'style={{display:props.dis}}>
    <div className={`container ${panelActive ? 'panel-active' : ''}`}>
      <div className="form-container sign-up-container">
        <form className="form" action="#" >
          <h1>Create Account</h1>
          <div className="social-container">
            <a href="#" className="social"><i className="fab fa-facebook-f"></i></a>
            <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
            <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a>
          </div>
          <span>Or use email for registration</span>
          <input type="text" placeholder="NAME" name='user' value={user} onChange={(e)=>{
            setUser(e.target.value);
          }}/>
          <input type="email" placeholder="EMAIL" name='email' value={email} onChange={(e)=>{
            setEmail(e.target.value);
          }} />
          <input type="password" placeholder="PASSWORD" name='password' value={password} onChange={(e)=>{
            setPassword(e.target.value);
          }}/>
          <button type="button" name="button" onClick={()=>{
            console.log("clicked");
            const postData = async ()=>{
                    try{
                        console.log("getting data...");
            const response = await axios.post('http://localhost:8000/signup/',{user:user,
            email:email,
            password:password,

            }
            
            ); 
            console.log(response);
            

            
                    }catch(err){
                        console.log(err);
                    }
            }
            
            postData();
            handler();
            
          }

          }>SIGN UP</button>
        </form>
      </div>

      <div className="form-container sign-in-container">
        <form className="form" action="#">
          <h1>Sign in</h1>
          <div className="social-container">
            <a href="#" className="social"><i className="fab fa-facebook-f"></i></a>
            <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
            <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a>
          </div>
          <span>Or use your account</span>
          <input type="email" placeholder="EMAIL" value={logemail} 
          onChange={(e)=>{
            setlogemail(e.target.value);
          }}/>
          <input type="password" placeholder="PASSWORD" value={logpassword}  onChange={(e)=>{
            setlogpassword(e.target.value);
          }}/>
          <p>forgot PASSWORD</p>
          <button type="button" name="button" onClick={()=>{ 
            const fetchdata = async ()=>{
                    try{
                        console.log("getting data...");
            const response = await axios.post('http://localhost:8000/',{email:logemail,
            password:logpassword,

            }
            
            ); 
            console.log(response.body);
            return response.body;
            

            
                    }catch(err){
                        console.log(err);
                    }
            }
            
            if (fetchdata.k !== true){
                 handler();
            }
            else{
                alert("wrong password");
            }
            
          }
}>SIGN in</button>
        </form>
      </div>

      <div className="overlay-container">
        <div className="overlay">
          <div className="overlay-panel overlay-right">
            <h1>Welcome</h1>
            <p>To connect with us please login</p>
            <button className="ghost" id="sign-in" onClick={handleSignInClick}>Sign in</button>
          </div>

          <div className="overlay-panel overlay-left">
            <h1>Hello</h1>
            <p>To join with us please Sign Up</p>
            <button className="ghost" id="sign-up" onClick={handleSignUpClick}>Sign Up</button>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
};

export default Entrypage;
