import React, { useState }  from "react";
import styles from './doubtsolver.module.css';
import Youquestion from "./youquestion";
import QuestionList from "./questionlist";


const DoubtSolver = (props)=>{
    const [quesDis,setQuesDis] = useState('none');
    function disap(state){
        setQuesDis(state);
    }
 return(
    <div className={styles.main} style={{display : props.dis}}>
        <div className={styles.header}>
           <h1>Doubt Solver</h1>

        </div>
        <div className={styles.questionbox}>
            <div className={styles.question}>
                
               <QuestionList ques=" Is the retrieval and integrity of the backed up data periodically reviewed? And have the backup and restore functionality been validated? 
                " header="How do you manage the data inconsistency?" />
               <br/>
               <QuestionList header="The previous and current value of the data" ques="Are unauthorized users prevented from altering electronic data or records? And are authorized modifications captured in an audit trail?"/>
            </div>


        </div>
        <div className={styles.query}>
            <span className={styles.querypoint} onClick={()=>{
                setQuesDis('block');
            }}>
                +
            </span>

        </div>
        <Youquestion dis={quesDis} setdis={disap}/>
    </div>
 );

}

export default DoubtSolver;