import React, { useEffect, useState } from "react";
import axios from 'axios';
import styles from './questionlist.module.css'

const QuestionList = (props)=>{

    
     
        return(
            <div className={styles.body}>
                <div className={styles.header}>
                    {props.header}
                </div>
                <div className={styles.question}>
                {props.ques}
                </div>
                <div className={styles.tags}>
                    #datamanagement #visualization
                </div>
                
                <div className={styles.category}>
                    ML/AI
                </div>
                
                
            </div>)
      


}

export default QuestionList;