import React, { useState }  from "react";
import styles from './doubtsolver.module.css';
import Youquestion from "./youquestion";
//import QuestionList from "./questionlist";


const DoubtSolver = ()=>{
    const [quesDis,setQuesDis] = useState('none');
    function disap(state){
        setQuesDis(state);
    }
 return(
    <div className={styles.main}>
        <div className={styles.header}>
           <h1>Doubt Solver</h1>

        </div>
        <div className={styles.questionbox}>
            <div className={styles.question}>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio repellat labore neque facere, doloremque ducimus dignissimos molestias quibusdam, ad voluptates quisquam expedita consequuntur omnis cum corporis fugit earum! Natus, fuga.
               
            </div>


        </div>
        <div className={styles.query}>
            <span className={styles.querypoint} onClick={()=>{
                setQuesDis('block');
            }}>
                +
            </span>

        </div>
        <Youquestion dis={quesDis} setdis={disap}/>
    </div>
 );

}

export default DoubtSolver;