import React from "react";
import styles from "./Youquestion.module.css";

const Youquestion = ({dis, setdis})=>{
    const setDip = ()=>{
        setdis('none');
    }
    
    return(
        <div className={styles.overlay}  style={{display : dis}}>
            
            <form className={styles.form} method="Post" action="http://localhost:8000/question/">
  <span className={styles.closer} onClick={setDip}>X</span>
  <label htmlFor="your_question">Your Question</label>
  <br/>
  <input type="text" placeholder="Enter your question"  name = "question"  className={styles.your_tags} id="question"  />
  <br/>
  <textarea name="your_question" cols="50" rows="10" className={styles.your_question} id="your_question" placeholder="Description...."/>
  <br/>
  <br/>
    <label htmlFor="category">Category : </label>
    
    <select className={styles.your_category} id="category"  name="category" >
      <option>AI/ML</option>
      <option>Web Dev</option>
      <option>AR/Vr</option>
      <option>App Development</option>
      <option>IOT</option>
      <option>Web 3.0</option>
    </select>
    <br/>
    <label htmlFor="tags">Tags : </label>
    <input type="text" placeholder="Enter your tags"  name = "tags"  className={styles.your_tags} id="tags"  />

  <br/>
  <div>
    <input type="submit" value="Submit" className={styles.submit} />
  </div>
</form>

        </div>
    )
}

export default Youquestion;