import React, { useState, useEffect } from 'react';
import './style.css';
import { BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import DoubtSolver from './doubtsolver';

function AssignmentHelp(){
    return(
        <div>
            <h1>Assignment Help</h1>
            <section className="home">
                <span className="image">
                    <img className='contentLogo' src="logo.jpg" alt=""/>
                </span>
                <p className="text">One Stop Solution</p>
                <p className="text-small">Empowering Education, Connecting Opportunities for Academic Success and Growth.</p>
                <div class="RightSection">
                    <div className='contentTitle'>
                        <h2>What is Assignment Help?</h2>
                    </div>
                    <div class="RightSectionNav">
                        
                        <ul class="mini-nav-list">
                            <li className='miniNavElements' onClick={()=>{
                                console.log("fgfg");
                              
                            }}>Doubt Solver </li>
                            <li className='miniNavElements'>Generate PPT</li>
                            <li className='miniNavElements'>Article Writer</li>
                            <li className='miniNavElements'>Essay Writer</li>
                            <li className='miniNavElements'>Story Writer</li>
                            <li className='miniNavElements'>Text Summarizer</li>
                        </ul>
                        
                    </div>

                </div>
                
                
            </section>

        </div>
    )
}

export default AssignmentHelp;