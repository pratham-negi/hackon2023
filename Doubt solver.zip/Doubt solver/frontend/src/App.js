import React from 'react';
import './App.css';
import DoubtSolver from './component/doubltsolver';

function App() {
  
  return (
    <div className="App">
    
      
      <DoubtSolver/>
  
      
    </div>
  );
}

export default App;
